var annotated_dup =
[
    [ "Employee", "class_employee.html", "class_employee" ],
    [ "RegionalEmployee", "class_regional_employee.html", "class_regional_employee" ]
];