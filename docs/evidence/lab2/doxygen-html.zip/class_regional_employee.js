var class_regional_employee =
[
    [ "RegionalEmployee", "class_regional_employee.html#aa2c5618413acd643e2fa4180f2ebda50", null ],
    [ "region", "class_regional_employee.html#a389fa2f7b3df88cbd0a0700de0ddfcb7", null ],
    [ "region_", "class_regional_employee.html#a75ab4dbb9118ed79a23b3ea4a5984d43", null ]
];