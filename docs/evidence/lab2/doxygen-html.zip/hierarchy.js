var hierarchy =
[
    [ "Employee", "class_employee.html", [
      [ "RegionalEmployee", "class_regional_employee.html", null ]
    ] ]
];