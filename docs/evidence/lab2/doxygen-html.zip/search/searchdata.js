var indexSectionsWithContent =
{
  0: "2acemnrt~вдлпрс—№",
  1: "er",
  2: "em",
  3: "aemnr~",
  4: "cnr",
  5: "2cmtвдлпрс—№"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Страницы"
};

