var searchData=
[
  ['region_5f_0',['region_',['../class_regional_employee.html#a75ab4dbb9118ed79a23b3ea4a5984d43',1,'RegionalEmployee']]]
];
