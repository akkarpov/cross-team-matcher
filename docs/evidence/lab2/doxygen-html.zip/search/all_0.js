var searchData=
[
  ['2_0',['Cross-Team Matcher — выполненная лабораторная № 2',['../index.html',1,'']]]
];
