var searchData=
[
  ['nickname_0',['nickname',['../class_employee.html#a9048da4bcef82168901660b20bd6709e',1,'Employee']]]
];
