var searchData=
[
  ['matcher_20—_20выполненная_20лабораторная_20№_202_0',['Cross-Team Matcher — выполненная лабораторная № 2',['../index.html',1,'']]]
];
