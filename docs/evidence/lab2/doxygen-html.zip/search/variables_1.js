var searchData=
[
  ['nickname_5f_0',['nickname_',['../class_employee.html#ab830f04a8dd85cd0ccd8e34647dfd16d',1,'Employee']]]
];
