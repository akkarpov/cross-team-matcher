var searchData=
[
  ['nickname_0',['nickname',['../class_employee.html#a9048da4bcef82168901660b20bd6709e',1,'Employee']]],
  ['nickname_5f_1',['nickname_',['../class_employee.html#ab830f04a8dd85cd0ccd8e34647dfd16d',1,'Employee']]]
];
