var class_employee =
[
    [ "Employee", "class_employee.html#ae4aa684c86684873a55b0a53bcfbc11a", null ],
    [ "~Employee", "class_employee.html#a01aa009d0ef6b36afdc4aea4da1123a1", null ],
    [ "available", "class_employee.html#a24f5a4118ff4b488cc75441173bbd915", null ],
    [ "nickname", "class_employee.html#a9048da4bcef82168901660b20bd6709e", null ],
    [ "capacity_", "class_employee.html#a3a07e2e43b8c8f5d8bf217e997bfa519", null ],
    [ "nickname_", "class_employee.html#ab830f04a8dd85cd0ccd8e34647dfd16d", null ]
];