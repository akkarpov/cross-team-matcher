var index =
[
    [ "Структура проекта", "index.html#structure", null ],
    [ "Проверенный пример", "index.html#example", null ],
    [ "Результат документирования", "index.html#documentation", null ]
];